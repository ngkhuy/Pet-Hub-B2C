export default function LoadingLogin() {
  // Or a custom loading skeleton component
  return <p>Loading...</p>;
}
