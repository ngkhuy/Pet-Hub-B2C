export default function AppFooter() {
  return (
    <footer>
      <p>Footer</p>
    </footer>
  );
}
