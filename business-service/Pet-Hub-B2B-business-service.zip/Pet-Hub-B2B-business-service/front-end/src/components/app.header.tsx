export default function AppHeader() {
  return (
    <header>
      <p>header</p>
    </header>
  );
}
