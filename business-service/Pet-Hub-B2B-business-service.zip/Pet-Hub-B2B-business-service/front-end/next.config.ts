import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  reactCompiler: false,
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "lh3.googleusercontent.com",
        port: "",
        pathname: "/**", // cho phép tất cả đường dẫn con
      },
    ],
  },
  // turbopack: {
  //   rules: {
  //     "*.svg": {
  //       loaders: [
  //         {
  //           loader: "@svgr/webpack",
  //           options: {
  //             icon: true,
  //           },
  //         },
  //       ],
  //       as: "*.js",
  //     },
  //   },
  // },
};

export default nextConfig;
